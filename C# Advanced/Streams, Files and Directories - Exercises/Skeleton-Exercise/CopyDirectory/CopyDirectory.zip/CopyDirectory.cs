﻿namespace CopyDirectory
{
    using System;
    using System.IO;

    public class CopyDirectory
    {
        static void Main()
        {
            string inputPath =  @$"{Console.ReadLine()}";
            string outputPath = @$"{Console.ReadLine()}";

            CopyAllFiles(inputPath, outputPath);
        }

        public static void CopyAllFiles(string inputPath, string outputPath)
        {
            File.Copy(inputPath, outputPath);
           //string[] filesInDir = Directory.GetFiles(inputPath);
           //string[] subDirs = Directory.GetDirectories(inputPath);

        }
    }
}
