﻿namespace CarManufacturer
{
    public class StartUp
    {
        static void Main()
        {
            Car car = new Car();
            car.Make = "Audi";
            car.Model = "A3";
            car.Year = 2001;
            car.FuelQuantity = 200;
            car.FuelConsumption = 7;

            car.Drive(2000);
            Console.WriteLine(car.WhoAmI());
        }
    }
}
